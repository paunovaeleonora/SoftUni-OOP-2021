class Employee:
    def get_fired(self):
        return f'fired...'